This is WeeW stack,

You can find here 2 folders:
1- Folder "070-STM32F1_ADC_LIBRARY_SETUP" with the code for the STM32F1 Blue pill to read the data using PA1 as ADC
2- Folder "PySerial_thread" with Python code to read the serial data coming from a Serial communication
3- Folder "003-Pyserial_Gui_Thread-1-Channel" Python code to read serial data coming from a microntroller with Optional display using GUI and Graphical visualization