void str_empty(char str[]);
void str_empty_len(char str[],char len);
int len_str(char str[]);
int find_str(char str1[], char str2[]);
int find_strL(char str1[], char str2[]);
void Concatstr(char str1[], char str2[]);
void int2char(int num, char str[]);
int char2int(char str[]);

